import os
import time
import threading
import PySimpleGUI as sg   

sg.theme('dark purple ')   #*change

path = os.getcwd()

#! Define the main window's contents (its a mess, dont even try to read it)
layout = [[[sg.Image(key="-3F-", size=(300,100),enable_events = True, background_color="white smoke",filename = os.getcwd()+"\F3.png"),sg.Image(key="-E3-", size=(100,100),enable_events = True, background_color="white smoke",filename = os.getcwd()+"\elevator.png"),sg.Image(key="-B3-", size=(100,100),enable_events = True, background_color="white smoke",filename = os.getcwd()+"\\3button.png")], 
          [sg.Image(key="-2F-", size=(300,100),enable_events = True, background_color="white smoke",filename = os.getcwd()+"\F2.png"),sg.Image(key="-E2-", size=(100,100),enable_events = True, background_color="white smoke",filename = os.getcwd()+"\elevator.png"),sg.Image(key="-B2-", size=(100,100),enable_events = True, background_color="white smoke",filename = os.getcwd()+"\\2button.png")],
          [sg.Image(key="-1F-", size=(300,100),enable_events = True, background_color="white smoke",filename = os.getcwd()+"\F1.png"),sg.Image(key="-E1-", size=(100,100),enable_events = True, background_color="white smoke",filename = os.getcwd()+"\elevator.png"),sg.Image(key="-B1-", size=(100,100),enable_events = True, background_color="white smoke",filename = os.getcwd()+"\\1button.png")],
          [sg.Image(key="-0F-", size=(300,100),enable_events = True, background_color="white smoke",filename = os.getcwd()+"\F0.png"),sg.Image(key="-E0-", size=(100,100),enable_events = True, background_color="white smoke",filename = os.getcwd()+"\elevator.png"),sg.Image(key="-B0-", size=(100,100),enable_events = True, background_color="white smoke",filename = os.getcwd()+"\\0button.png")]]]

#! Create main window
window = sg.Window('Building', layout) 

building = [[0,0,0],[0,0,0],[0,0,0],[0,0,0]] #one list for each flor, [state(calling elevator),n ppl awaiting, n ppl incoming]
elevator = [0,[]]

def elevatorSystem():#elevator logic, called by thread, images updates also done here
    while True:
        print("Elevator operational")
        time.sleep(5)
        if kill_thread:
            break
    
#creates a thread for the elevator, necessary for updating values while the main programming still interactive
t = threading.Thread(target=elevatorSystem)
kill_thread = False
t.start()

#! Event loop
while True:
    event, values = window.read()                   
    if event == sg.WINDOW_CLOSED: #? Exits
        break
    #*Add ppl ========================================================
    elif event == "-3F-":
        print("add person 3 floor")
        if building[3][1] > 4:
            sg.popup("max amount of ppl reache on floor 3", title=":(",text_color="red")
        else: building[3][1] +=1

    elif event == "-2F-":
        print("add person 3 floor")
        if building[2][1] > 4:
            sg.popup("max amount of ppl reache on floor 2", title=":(",text_color="red")
        else: building[2][1] +=1

    elif event == "-1F-":
        print("add person 3 floor")
        if building[1][1] > 4:
            sg.popup("max amount of ppl reache on floor 1", title=":(",text_color="red")
        else: building[1][1] +=1

    elif event == "-0F-":
        print("add person 3 floor")
        if building[0][1] > 4:
            sg.popup("max amount of ppl reache on floor 0", title=":(",text_color="red")
        else: building[0][1] +=1

    #* Call Elevator====================================================
    elif event == "-E3-":
        window['-E3-'].update(filename= path + '/elevatorcall.png')
        print("called E3")
    elif event == "-E2-":
        window['-E2-'].update(filename= path + '/elevatorcall.png')
        print("called E2")
    elif event == "-E1-":
        window['-E1-'].update(filename= path + '/elevatorcall.png')
        print("called E1")
    elif event == "-E0-":
        window['-E0-'].update(filename= path + '/elevatorcall.png')
        print("called E0")

    #* Elev buttons ====================================================
    elif event == "-B3-":
        print("pressed B3")
    elif event == "-B2-":
        print("pressed B2")
    elif event == "-B1-":
        print("pressed B1")
    elif event == "-B0-":
        print("pressed B0")

window.close()
print(building)   
print(elevator)
kill_thread = True
t.join()#kills thread